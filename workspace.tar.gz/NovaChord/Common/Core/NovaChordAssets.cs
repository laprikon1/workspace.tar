using InnoVault;
using Microsoft.Xna.Framework.Graphics;
using ReLogic.Content;

namespace NovaChord.Common.Core
{
    /// <summary>
    ///     Central texture registry. InnoVault's <see cref="VaultLoadenAttribute" /> resolves the
    ///     asset mode from the field type and requests the assets during mod loading, so no
    ///     manual <c>Mod.Assets.Request</c> bookkeeping is needed anywhere else in the mod.
    /// </summary>
    public static class NovaChordAssets
    {
        private const string Tex = "Assets/Textures/";

        [VaultLoaden(Tex + "Particles/StarSpark")]
        public static Asset<Texture2D> StarSpark = null;

        [VaultLoaden(Tex + "Particles/SoftGlow")]
        public static Asset<Texture2D> SoftGlow = null;

        [VaultLoaden(Tex + "Particles/HaloRing")]
        public static Asset<Texture2D> HaloRing = null;

        [VaultLoaden(Tex + "Particles/RunePetal")]
        public static Asset<Texture2D> RunePetal = null;

        [VaultLoaden(Tex + "Particles/FrostShard")]
        public static Asset<Texture2D> FrostShard = null;

        [VaultLoaden(Tex + "Particles/Mote")]
        public static Asset<Texture2D> Mote = null;

        [VaultLoaden(Tex + "Particles/CadenceNoise")]
        public static Asset<Texture2D> CadenceNoise = null;

        [VaultLoaden(Tex + "Projectiles/ResonanceArrow")]
        public static Asset<Texture2D> Arrow = null;

        [VaultLoaden(Tex + "Projectiles/StarfallLance")]
        public static Asset<Texture2D> Lance = null;

        [VaultLoaden(Tex + "Projectiles/CadenceHoldout")]
        public static Asset<Texture2D> Holdout = null;
    }
}
