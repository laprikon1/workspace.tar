import urllib.request, os, sys, concurrent.futures
def get(url):
    req = urllib.request.Request(url, headers={'User-Agent':'research'})
    return urllib.request.urlopen(req, timeout=60).read()
def dl(args):
    owner, repo, branch, path = args
    out = f'research/{repo}/{path}'
    os.makedirs(os.path.dirname(out), exist_ok=True)
    if os.path.exists(out): return 'cached '+path
    try:
        data = get(f'https://raw.githubusercontent.com/{owner}/{repo}/{branch}/{path}')
        open(out,'wb').write(data)
        return f'ok {path} {len(data)}'
    except Exception as e:
        return f'ERR {path} {e}'
if __name__=='__main__':
    owner, repo, branch = sys.argv[1:4]
    pats = sys.argv[4:]
    paths = open(f'research/{repo}/_tree.txt').read().split('\n')
    sel = [p for p in paths if any(p.startswith(x) or x in p for x in pats)]
    with concurrent.futures.ThreadPoolExecutor(8) as ex:
        for r in ex.map(dl, [(owner,repo,branch,p) for p in sel]):
            print(r)
