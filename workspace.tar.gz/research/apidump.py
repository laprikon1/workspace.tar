import xml.etree.ElementTree as ET, os, sys, re, collections
def dump(xmlpath, outdir):
    t=ET.parse(xmlpath); r=t.getroot()
    per=collections.defaultdict(list)
    for m in r.iter('member'):
        name=m.get('name')
        if not name: continue
        kind, _, sig = name.partition(':')
        # type is everything up to last '.' before '(' 
        base = sig.split('(')[0]
        parts = base.split('.')
        if kind in ('M','P','F','E'):
            typ='.'.join(parts[:-1]); member=parts[-1]
        else:
            typ=base; member=''
        args=''
        if '(' in sig: args='('+sig.split('(',1)[1]
        summary=' '.join((m.findtext('summary') or '').split())
        per[typ].append(f'{kind} {member}{args}   {(("# "+summary[:160]) if summary else "")}')
    os.makedirs(outdir, exist_ok=True)
    idx=[]
    for typ, lines in sorted(per.items()):
        fn=typ.replace('`','_')+'.txt'
        open(os.path.join(outdir,fn),'w').write(typ+'\n'+'\n'.join(sorted(set(lines))))
        idx.append(f'{typ}  ({len(set(lines))})')
    open(os.path.join(outdir,'_index.txt'),'w').write('\n'.join(idx))
    print(outdir, len(per),'types')
dump('/tmp/tools/libs/InnoVault.xml','research/api/InnoVault')
dump('research/Luminance/Luminance.xml','research/api/Luminance')
dump('/tmp/tools/libs/ParticleLibrary.xml','research/api/ParticleLibrary')
